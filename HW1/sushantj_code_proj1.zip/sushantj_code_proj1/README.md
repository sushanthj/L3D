# Running main.py

1. Create a folder called "images" in the same folder which contains main.py (this will be our output folder)
2. Clone the data required to run the images from: ```https://github.com/learning3d/assignment1/tree/master/data```
3. Run ```python3 main.py --image_size 256```
4. If you want to render the BB8 (render something cool task) then uncomment the last line of main.py